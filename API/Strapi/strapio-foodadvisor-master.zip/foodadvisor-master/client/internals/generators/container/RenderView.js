import React from 'react';
// import PropTypes from 'prop-types';

/* eslint-disable no-unused-vars */
const RenderView = data => {
  return <div />;
};

RenderView.defaultProps = {};

RenderView.propTypes = {};

export default RenderView;
