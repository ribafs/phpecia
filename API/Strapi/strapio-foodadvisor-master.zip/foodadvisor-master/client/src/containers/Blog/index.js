/**
 *
 * Blog
 *
 */

import React from 'react';
// import PropTypes from 'prop-types';

function Blog() {
  return <div>Blog</div>;
}

Blog.defaultProps = {};
Blog.propTypes = {};

export default Blog;
