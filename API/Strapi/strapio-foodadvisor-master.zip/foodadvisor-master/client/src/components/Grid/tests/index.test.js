import React from 'react';
import { mount } from 'enzyme';
// import { enzymeFind } from 'styled-components/test-utils';

import Grid from '../index';

describe('<Grid />', () => {
  it('Expect to have unit tests specified', () => {
    mount(<Grid />);
  });
});
