const colors = {
  lightBeige: '#fffcfa',
  darkBeige: '#f3ded4',
  darkBlue: '#202675',
  mediumGrey: '#bfbfbf',
  lightGrey: '#e7e7e7',
  darkGrey: '#969696',
  black: '#191919',
  lightOrange: '#f2cbb9',
  greyBkdg: '#fdfdfd',
  greyBorder: '#f3f3f3',
};

export default colors;
