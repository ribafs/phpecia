const fonts = {
  light: `font-family: 'Open Sans'; font-weight: 200;`,
  reg: `font-family: 'Open Sans'; font-weight: 400;`,
  bold: `font-family: 'Open Sans'; font-weight: 700;`
};

export default fonts;
